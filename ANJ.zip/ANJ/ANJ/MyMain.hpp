//
//  MyMain.h
//  AlineNJ
//
//  Created by iOSLab11 on 10/29/19.
//  Copyright © 2019 iOSLab11. All rights reserved.
//
#import "MyMain.cpp"

class Aline_Wrapper {
public:
    int Aline_seq();
};
