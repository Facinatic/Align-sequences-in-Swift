//
//  Aline_W.mm
//  ANJ
//
//  Created by iOSLab11 on 11/5/19.
//  Copyright © 2019 iOSLab11. All rights reserved.
//

#import "Aline_W.h"
#import "MyMain.hpp"

@implementation Aline_W

-(int) Aline_Full;
{
    Aline_Wrapper Alines;
    Alines.Aline_seq();
    return 0;
}
@end
